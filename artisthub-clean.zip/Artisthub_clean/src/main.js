import './js/api.js';                 
import './js/artists/index.js';       

import './js/header.js';
import './js/hero.js';
import './js/comments.js';
import "./js/global-sfx.js";
